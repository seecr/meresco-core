from distutils.core import setup

setup(
    name='cq2utils',
    packages=['cq2utils', 'cq2utils.networking', 'cq2utils.streams', 'cq2utils.xmlutils'],
)

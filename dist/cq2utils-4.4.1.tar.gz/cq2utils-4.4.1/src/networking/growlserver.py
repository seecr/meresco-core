## begin license ##
#
#    "CQ2 Utils" (cq2utils) is a package with a wide range of valuable tools.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of "CQ2 Utils".
#
#    "CQ2 Utils" is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    "CQ2 Utils" is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with "CQ2 Utils"; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##
from cq2utils.pushbind import pushbind
import time, traceback

from xml.sax.saxutils import escape as xmlEscape

resultTemplate = """<result id="%s"><status>%s</status><message>%s</message></result>\n"""

class GrowlServer:
	
	def __init__(self, aReadWriteStream, args = None):
		self._stream = aReadWriteStream
		
	def _write(self, aString):
		self._stream.write(aString)
		self._stream.flush()
		
	def process(self):
		iter = pushbind('document', self._stream)
		self._write('<?xml version="1.0"?>\n<results>\n')	
		try:	
			for aDocument in iter:
				try:
					self._processDocument(aDocument)
					self._writeOkResult(aDocument.id)
				except Exception, e:
					self._writeErrorResult(aDocument.id, traceback.format_exc())
		finally:
			self._postProcess()
			self._write('</results>')
	
	def _writeErrorResult(self, anId, aMessage):
		self._write(resultTemplate % (xmlEscape(anId), 'ERROR', xmlEscape(aMessage)))
			
	def _writeOkResult(self, anId):
		self._write(resultTemplate % (xmlEscape(anId), 'OK', ''))
			
	def _postProcess(self):
		"""Hook method: do any server-scale postprocessing here"""
		pass
	
	def _processDocument(self, aDocument):
		raise NotImplementedError("GrowlServer Subclasses should implement _processDocument")
	

#!/usr/bin/env python
## begin license ##
#
#    "CQ2 Utils" (cq2utils) is a package with a wide range of valuable tools.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of "CQ2 Utils".
#
#    "CQ2 Utils" is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    "CQ2 Utils" is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with "CQ2 Utils"; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##

import sys
from cq2utils.streams.readwritestream import ReadWriteStream
from cq2utils.streams.osreadstream import OSReadStream
import os, tempfile, traceback

TMPDIR = '/tmp/sshserver'

class SSHServerException(Exception):
	pass
		
def raiseException(message):
	ex = SSHServerException(message)
	
	os.path.isdir(TMPDIR) or os.makedirs(TMPDIR)
	fd,filename = tempfile.mkstemp(dir=TMPDIR)
	try:
		os.write(fd, str(message))
	finally:
		os.close(fd)
	raise ex

class SSHServer:
	
	def __init__(self, handlerClass, argv = None):
		self._handlerClass = handlerClass
		self._argv = argv
	
	def main(self):
		try:
			stream = ReadWriteStream(
				OSReadStream(sys.stdin.fileno()),
				sys.stdout)
			object = self._handlerClass(stream, self._argv)
			object.process()
			EOF = '\4'
			stream.write(EOF)
		except Exception, e:
			raiseException(e)
## begin license ##
#
#    "CQ2 Utils" (cq2utils) is a package with a wide range of valuable tools.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of "CQ2 Utils".
#
#    "CQ2 Utils" is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    "CQ2 Utils" is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with "CQ2 Utils"; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##

# The following is a modified direct copy of amara (v. 1.0) binderytools.py lines 663 - 775 (starting here at line 8)

from amara import saxtools
from xml import sax
from amara.binderytools import *
from cStringIO import StringIO

import amara
supported_versions=['1.1.7', '1.2.0.1', '1.2a2']
if amara.__version__ not in supported_versions:
  raise Exception('Amara version %s needed for cq2utils.pushbind.' % ' or '.join(supported_versions))

class PushbindException(Exception):
	pass

def pushbind(xpatterns, source, prefixes=None, rules=None, event_hook=None):
    """
    Generator that yields subtrees of Python object bindings from XML
    according to the given pattern.  The patterns are must be XSLT patterns
    matching elements.
    
    Example: for an xml document
    
    XML = '<a> <b><c/></b> <b><c/></b> <b><c/></b> </a>'
    
    pushbind('b', string=XML)
    Will return a generator that yields the first, second and third b
    element in turn as Python objects containing the full subtree.
    
    Warning: this function uses threads and only works in Python distros
    with threading support.

    lookahead - how far ahead the SAX engine looks for events before waiting
    for the user to request another subtree from the generator.  0 means
    the SAX engine will just load and queue up object for
    the entire file in the background.
    """
    parser = Sax.CreateParser()
    parser.setFeature(Sax.FEATURE_GENERATOR, True)

    def handle_chunk(node):
        parser.setProperty(Sax.PROPERTY_YIELD_RESULT, node)

    #Create an instance of the chunker
    handler = saxbind_chunker(xpatterns=xpatterns, prefixes=prefixes,
        chunk_consumer=handle_chunk, rules=rules, event_hook=event_hook
    )

    parser.setContentHandler(handler)
    if isinstance(source, InputSource.InputSource):
        pass
    elif hasattr(source, 'read'):
        #Create dummy Uri to use as base
        dummy_uri = 'urn:uuid:'+Uuid.UuidAsString(Uuid.GenerateUuid())
        source = InputSource.DefaultFactory.fromStream(source, dummy_uri)
    elif IsXml(source):
        #Create dummy Uri to use as base
        dummy_uri = 'urn:uuid:'+Uuid.UuidAsString(Uuid.GenerateUuid())
        source = InputSource.DefaultFactory.fromString(source, dummy_uri)
    elif Uri.IsAbsolute(source): #or not os.path.isfile(source):
        source = InputSource.DefaultFactory.fromUri(source)
    else:
        #Create dummy Uri to use as base
        dummy_uri = 'urn:uuid:'+Uuid.UuidAsString(Uuid.GenerateUuid())
        source = InputSource.DefaultFactory.fromStream(StringIO(source), dummy_uri)

    try:
      for elem in parser.parse(source):
        yield elem
    except Exception, e:
      raise PushbindException(e)


def xpushbind(xpatterns, source=None, string=None, prefixes=None,
             rules=None, lookahead=2):
    """
    Generator that yields subtrees of Python object bindings from XML
    according to the given pattern.  The patterns are must be XSLT patterns
    matching elements.
    
    Example: for an xml document
    
    XML = '<a> <b><c/></b> <b><c/></b> <b><c/></b> </a>'
    
    pushbind('b', string=XML)
    Will return a generator that yields the first, second and third b
    element in turn as Python objects containing the full subtree.
    
    Warning: this function uses threads and only works in Python distros
    with threading support.

    lookahead - how far ahead the SAX engine looks for events before waiting
    for the user to request another subtree from the generator.  Must be 0 or
    at least 2.  0 means the SAX engine will just load and queue up object for
    the entire file in the background.
    """
    #Saved some pondering by reference to Jimmy Retzlaff
    #http://groups-beta.google.com/group/comp.lang.python/msg/982bd32c08450352
    if lookahead == 2: lookahead = 1
    import Queue
    try:
        import threading
    except ImportError:
        import dummy_threading as threading
    queue = Queue.Queue(lookahead)
    def handle_chunk(docfrag):
        queue.put(docfrag)
        return

    #Create an instance of the chunker
    handler = saxbind_chunker(xpatterns=xpatterns, prefixes=prefixes,
        chunk_consumer=handle_chunk, rules=rules
    )

    def launch_sax():
        parser = sax.make_parser()

        #The chunker is the SAX handler
        parser.setContentHandler(handler)
        parser.setFeature(sax.handler.feature_namespaces, 1)
        try:
            if source:
                parser.parse(source)
            else:
                from cStringIO import StringIO
                parser.parse(StringIO(string))
        except Exception, e:
            queue.put(e)
        queue.put(None)  #Sentinel to mark that we're done
        return

    sax_thread = threading.Thread(target=launch_sax)
    sax_thread.setDaemon(True)
    sax_thread.start()

    while True:
        elem = queue.get()
        if elem:
            print elem
            #if isinstance(elem, Exception):
            #    raise PushbindException(elem)
            yield elem
        else:
            break
    return

## begin license ##
#
#    "CQ2 Utils" (cq2utils) is a package with a wide range of valuable tools.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of "CQ2 Utils".
#
#    "CQ2 Utils" is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    "CQ2 Utils" is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with "CQ2 Utils"; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##
from StringIO import StringIO
from itertools import groupby
from normalize import Normalize
from lxml.etree import Element, tostring, ElementTree, SubElement, parse, XMLSyntaxError, XPathSyntaxError
from xml.sax.saxutils import escape, unescape
from re import compile

unzip = lambda listOfTuples: zip(*listOfTuples)
xPathSplitter = compile('[^/]*\[[^\]]*\]|[^/]+')

class XMLRewrite:
	"""
	XMLRewrite processes rules that create a new XML record out of an existing one.
	The new record is written from scratch.  The rules are tuples in the following format:
	(newPath, oldPath, (valuePath,...), template, *normalizationRules)

	newPath:	The names of the elements to create under the root tag e.g. 'lifecycle/contribute'.
		The multiplicity of these elements will correspond to the oldPath so the tree described by
		newPath will be exactly the same as the one described by oldPath, except for the
		tag names.  If newPath is longer than oldPath, the system descents into newPath --
		meanwhile creating elements when needed -- until the remainder is as long as oldPath.
		The it starts creating elements from there.

	oldPath:		The names of the elements in the source that are to be taken as source, e.g.
		'lifeCycle/contribute'.  For each elements found in this path a corresponding element in newPath
		is created.  The subtree identified by oldPath is mirrored in newPath.  If oldPath is longer
		than newPath, the systems descents into oldPath until the remainder is as long as newPath.
		It then starts mirroring the tree from there.

	(valuePath,...):		For each leaf element found in oldPath a tuple of values is collected by
		evaluating the valuePaths relative to the leaf element.  E.g. to collect 'language' and 'value'
		from a 'langstring' element within the leaf element, use: ('langstring/language', langstring/value').
		The system will create a series of value tuples when the valuePaths have multiple	matches, e.g.
		when multiple 'langstring's are present.

	template:	Each tuple with values from valuePath is applied to a template string using the modulo
		operator.  The template must be a Python formatting string with as many slots as valuePaths. For
		example '<string language="%s">%s</language>'. When valuePaths result in multiple matches,
		the template is applied once for each tuple in the series.  The template can contain either valid
		XML or plain text.  Valid XML is parsed and added to the leaf element. Plain text is inserted into
		the leaf element directly.

	*normalizationRules:		This is a list of rules which, if present, is passed to the Normalize class.  The rules
		are executed for each value yielded by valuePaths, before it is fed to the template.
		See the documentation of Normalize for more information.

	"""

	def __init__(self, orgElementTree, rootTagName=None, defaultNameSpace=None,
				 rules = None, vocabDict=None, xPathNs={}):
		self.orgTree = orgElementTree
		nsmap = defaultNameSpace != None and {None: defaultNameSpace} or {}
		assert isinstance(rootTagName, basestring), type(rootTagName)
		self.newTree = ElementTree(Element(rootTagName, nsmap=nsmap))
		self.rules = rules
		self.xPathNs = xPathNs
		self.globalVocabRewrite = vocabDict
		self.globalVocabRewrite[None] = ''

	def toString(self):
		return tostring(self.newTree, pretty_print=True)

	def descent(self, (orgContext, orgPath), (newContext, newPath), *args):
		if len(orgPath) > len(newPath):
			for orgContext in self.evalXpath(orgContext, orgPath[0]):
				self.descent((orgContext, orgPath[1:]), (newContext, newPath), *args)
		elif len(newPath) > len(orgPath):
			newContexts = self.evalXpath(newContext, newPath[0])
			if not newContexts:
					newContext.append(Element(newPath[0]))
			for newContext in self.evalXpath(newContext, newPath[0]):
				self.descent((orgContext, orgPath), (newContext, newPath[1:]), *args)
		else:
			if orgPath:
				newTag = newPath[0]
				orgSubContexts = self.evalXpath(orgContext, orgPath[0])
				newSubContexts = self.evalXpath(newContext, newTag)
				for n in range(len(newSubContexts), len(orgSubContexts)):
					newContext.append(Element(newTag))
				newSubContexts = self.evalXpath(newContext, newTag)
				for orgSubContext, newSubContext in zip(orgSubContexts, newSubContexts):
					self.descent((orgSubContext, orgPath[1:]), (newSubContext, newPath[1:]), *args)
			else:
				self.createSubElements(orgContext, newContext, *args)

	def findNameSpaces(self, node, cache={}):
		if node in cache:
			return cache[node]
		nsmap = getattr(node, 'nsmap', {})
		parent = node.getparent()
		if parent:
			nsmap.update(self.findNameSpaces(parent))
		nsmap.update(self.xPathNs)
		if None in nsmap: del nsmap[None]
		cache[node] = nsmap
		return nsmap

	def evalXpath(self, node, path):
		ns = self.findNameSpaces(node)
		try:
			return node.xpath(path, ns)
		except XPathSyntaxError, e:
			print '>>>>>>>>>>', self.xPathNs
			raise XPathSyntaxError('%s: "%s"; Defined namespaces: %s' % (str(e.error_log), path, str(ns)))

	def createSubElements(self, orgContext, newContext, valuePaths, template, normalizationRules=None):
		valueElements = tuple(self.evalXpath(orgContext,path) for path in valuePaths)
		values = tuple(self.mapValues(values, normalizationRules) for values in unzip(valueElements))
		for arguments in values:
			try:
				data = template % arguments
			except TypeError, e:
				raise TypeError('%s: %s: %s %% %s' % (e, context, template, arguments))
			if data and data.startswith('<'):
				try:
					newElement = parse(StringIO(data)).getroot()
				except XMLSyntaxError, e:
					raise XMLSyntaxError('%s: %s' % (str(e), (template, arguments, data)))
				newContext.append(newElement)
			elif data:
				newContext.text = unescape(data)

	def mapValues(self, values, normalizationRules):
		newValues = (self.globalVocabRewrite.get(getattr(value,'text', value), getattr(value,'text', value)) for value in values)
		if normalizationRules:
			normalize = Normalize(normalizationRules)
			newValues = (normalize.process(value) for value in newValues)
		return tuple(escape(value) for value in newValues)

	def rewrite2(self, dstEltPath, srcEltPath, *args):
		self.descent((self.orgTree.getroot(), xPathSplitter.findall(srcEltPath)), (self.newTree.getroot(), xPathSplitter.findall(dstEltPath)), *args)

	def applyRules(self):
		for rule in self.rules:
			self.rewrite2(*rule)

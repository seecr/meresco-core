#include <string>

class TestClass1 {
private:
    std::string _aString;
public:
  TestClass1(void);
  std::string helloWorld(void);
  std::string getString(void);
  std::string passString(std::string aString);
};

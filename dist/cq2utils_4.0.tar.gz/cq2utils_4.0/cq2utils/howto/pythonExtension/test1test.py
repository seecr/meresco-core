## begin license ##
#
#    "CQ2 Utils" (cq2utils) is a package with a wide range of valuable tools.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of "CQ2 Utils".
#
#    "CQ2 Utils" is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    "CQ2 Utils" is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with "CQ2 Utils"; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##
import unittest

class Test1Test(unittest.TestCase):
	def testImport(self):
		from test1 import TestClass1
		
	def testGetString(self):
		import test1
		testobj = test1.TestClass1()
		result = testobj.getString()
		self.assertEquals("string0", result)

	def testCallHelloWorld(self):
		import test1
		testobj = test1.TestClass1()
		result = testobj.helloWorld()
		self.assertEquals("Hello!", result)
	
	def testPassString(self):
		import test1
		testobj = test1.TestClass1()
		result = testobj.passString("string1")
		self.assertEquals("string0",result)
		result = testobj.passString("string2")
		self.assertEquals('string1', result)
		result = testobj.passString("string3")
		self.assertEquals('string2', result)
		
	def testPublicModuleAttributes(self):
		import test1
		allAttributes = dir(test1)
		self.assertFalse('stat' in allAttributes)
		self.assertTrue('TestClass1' in allAttributes)

if __name__ == '__main__':
	unittest.main()

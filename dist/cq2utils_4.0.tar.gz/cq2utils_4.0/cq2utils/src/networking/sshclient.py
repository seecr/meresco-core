## begin license ##
#
#    "CQ2 Utils" (cq2utils) is a package with a wide range of valuable tools.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of "CQ2 Utils".
#
#    "CQ2 Utils" is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    "CQ2 Utils" is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with "CQ2 Utils"; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##
import os, tempfile
from cq2utils.streams.oswritestream import OSWriteStream
from cq2utils.streams.osreadstream import OSReadStream

import popen2

SSH_BINARY = '/usr/bin/ssh'
SSH_OPTIONS = '-o BatchMode=yes -p %(port)s -i %(keyfile)s -l %(username)s %(host)s'

def openClient(hostname, port, username, privatekey, remoteCommand):
	result = SSHClient(hostname, port, username, privatekey, remoteCommand)
	result.openConnection()
	return result

open = openClient # Some application still use open

class SSHClient:
	"""Known limitation: crashing other side is not dealt with properly"""
	
	def __init__(self, hostname, port, username, privatekey, remoteCommand):
		self._hostname = hostname
		self._username = username
		self._port = port
		self._privateKey = privatekey
		self._remoteCommand = remoteCommand
		
		self._toRemote = None
		self._fromRemote = None
		self._keyFilename = ''
		self._childProcess = None
		
	def isConnected(self):
		return self._childProcess and self._toRemote != None and self._fromRemote != None
	
	def openConnection(self):
		self._keyFilename = self._writeKeyToFile()
		try:
			self._toRemote, self._fromRemote = self._createConnection()
		except:
			self._removeKeyFile()
			raise

	def close(self):
		try:
			if self.isConnected():
				self._toRemote.close() #kvs & eg vinden dit een beetje vreemd omdat het proces vanzelf eindigt 2006-05-03
				self._fromRemote.close()
				self._toRemote = self._fromRemote = None
		finally:
			self._removeKeyFile()
			
	def read(self, bytes = -1):
		return self._fromRemote.read(bytes)
	
	def write(self, aString):
		self._toRemote.write(aString)
		
	def flush(self):
		"""SSHClient flushes automatically"""
		pass

	def _exec(self, command):
		return popen2.Popen3(command, True)

	def _createConnection(self):
		#print "\n\n\n" + self._createCallString() + "\n\n\n"
		self._childProcess = self._exec(self._createCallString())
		fromRemote, toRemote = self._childProcess.fromchild, self._childProcess.tochild

		wrappedFromRemote = OSReadStream(fromRemote.fileno())
		wrappedToRemote = OSWriteStream(toRemote.fileno())
		return wrappedToRemote, wrappedFromRemote

	def _createCallString(self):
		sshOptionDict = {'port': self._port, 'host': self._hostname, 'username': self._username, 'keyfile':self._keyFilename}
		return '%s %s "%s"' % (SSH_BINARY, SSH_OPTIONS % sshOptionDict, self._remoteCommand)

	def _writeKeyToFile(self):
		if not self._keyFilename:
			(fd, keyFilename) = tempfile.mkstemp()
			try:
				os.write(fd, self._privateKey)
			finally:
				os.close(fd)
			return keyFilename
		return self._keyFilename

	def _removeKeyFile(self):
		if self._keyFilename:
			os.unlink(self._keyFilename)
			self._keyFilename = None

## begin license ##
#
#    "CQ2 Utils" (cq2utils) is a package with a wide range of valuable tools.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of "CQ2 Utils".
#
#    "CQ2 Utils" is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    "CQ2 Utils" is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with "CQ2 Utils"; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##
import sys, os, select

class SplittingBaseStream:
	
	def __init__(self, original, replica):
		self._original = original
		self._replica = replica
		
	def __getattr__(self, name):
		return getattr(self._original, name)
	
	def __hasattr__(self, name):
		return hasattr(self._original, name)

	def close(self):
		self._original.close()
		self._replica.close()

class SplittingReadStream(SplittingBaseStream):
	
	def read(self, nrOfBytes = -1):
		result = self._original.read(nrOfBytes)
		self._replica.write(result)
		self._replica.flush()
		return result
	
class SplittingWriteStream(SplittingBaseStream):
	
	def write(self, aString):
		self._replica.write(aString)
		self._original.write(aString)
		
	def flush(self):
		self._replica.flush()
		self._original.flush()

## begin license ##
#
#    "CQ2 Utils" (cq2utils) is a package with a wide range of valuable tools.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of "CQ2 Utils".
#
#    "CQ2 Utils" is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    "CQ2 Utils" is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with "CQ2 Utils"; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##
import binderytools
from amara import bindery
import types
from itertools import imap

def wrapp(object):
	if isinstance(object, dict) or 'FieldStorage' in object.__class__.__name__:
		return WrapDict(object)
	if isinstance(object, list):
		return WrapList(object)
	if isinstance(object, (str, unicode)):
		return WrapString(object)
	if isinstance(object, (bindery.element_base, bindery.root_base)):
		return WrapAmara(object)
	return object

class WrapperException(Exception):
	pass

class BaseWrapper:
	def __init__(self, delegatee):
		self._delegatee = delegatee
		try:
			u = unicode(delegatee)
			self._string = u.encode('utf-8')
		except UnicodeDecodeError, e:
			self._string = str(delegatee)

	def __getattr__(self, name):
		try:
			return wrapp(self.getMagicAttr(name))
		except (AttributeError, KeyError):
			try:
				if name == 'title': 
					return WrapTitle(self._string)
				return getattr(self._delegatee, name)
			except AttributeError:
				try:
					return getattr(self.__repr__(), name)
				except AttributeError:
					if name.startswith('__'): raise AttributeError
					return self.terminator(name)
		
	def getMagicAttr(self, name):
		raise AttributeError
	
	def terminator(self, name):
		#return wrapp(u'') Check met Erik
		return WrapString(u'')

	def __repr__(self):
		return self._string

	def __str__(self):
		return self.__repr__()

	def __int__(self):
		return int(str(self))

	def __coerce__(self, other):
		return self.__repr__(), str(other)

	def __getitem__(self, key):
		return WrapString(u'')
	
	def __hash__(self):
		return self.__repr__().__hash__()

	def __contains__(self, anItem):
		return str(anItem) in self._delegatee


class WrapString(BaseWrapper):
	def __iter__(self):
		return self._delegatee and iter([self._delegatee]) or iter([])
			

class WrapList(BaseWrapper):
	def __repr__(self):
		return len(self._delegatee) and self._delegatee[0] or ''

	def __getitem__(self, key):
		return wrapp(self._delegatee.__getitem__(key))


class WrapDict(BaseWrapper):
	
	def getMagicAttr(self, name):
		return self._delegatee[name]

	def __getitem__(self, key):
		return wrapp(self._delegatee.__getitem__(key))

class WrapAmara(BaseWrapper):
	
	def __init__(self, delegatee):
		self._delegatee = delegatee
		
		if isinstance(self._delegatee, bindery.root_base):
			self._string = 'yes'
		else:
			self._string = unicode(self._delegatee.xml_child_text)
	
	def __nonzero__(self):
		return self._string != ''
	
	def getMagicAttr(self, name):
		if name in dir(bindery.element_base):
			raise AttributeError
		return getattr(self._delegatee, name)
		
	def __getitem__(self, key):
		try:
			return getattr(self, key)
		except TypeError:
			try:
				return WrapAmaraWithIterFix(self._delegatee[key])
			except (AttributeError, TypeError):
				return getattr(self, str(key))

	def __iter__(self):
		return imap(wrapp, self._delegatee.__iter__())
	
	def __setattr__(self, key, value):
		if not key in ['_delegatee', '_string', '__iter__']:
			raise WrapperException("Wrappers do not support setting of attributes")
		self.__dict__[key] = value
		
class WrapAmaraWithIterFix(WrapAmara):
	"""Amara object has the following behavior:
	a = binderytools.bind_string('<a><b>1</b><b>2</b><b>3</b></a>').a
	list(a.b[1]) == ['2','3']
	We expect it to be ['2']
This class fixes that behavior"""
	def __iter__(self):
		return imap(wrapp, [self._delegatee].__iter__())

	
class WrapTitle(WrapString):
	def __init__(self, delegatee):
		WrapString.__init__(self,'')
		self._mytitle = delegatee
		
	def __call__(self):
		return self._mytitle.title()
		

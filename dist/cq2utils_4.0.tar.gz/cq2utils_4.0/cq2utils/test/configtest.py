## begin license ##
#
#    "CQ2 Utils" (cq2utils) is a package with a wide range of valuable tools.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of "CQ2 Utils".
#
#    "CQ2 Utils" is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    "CQ2 Utils" is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with "CQ2 Utils"; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##
from unittest import TestCase

from config import read
from tempfile import mkstemp
from os import remove

class ConfigTest(TestCase):
	def setUp(self):
		fd, self.configfile = mkstemp()
		
	def tearDown(self):
		remove(self.configfile)
	
	def createConfig(self, configtext):
		f = open(self.configfile, 'w')
		try:
			f.write(configtext)
		finally:
			f.close()
		return read(self.configfile)
	
	def testReadEmptyConfig(self):
		config = self.createConfig('')
		self.assertEquals({}, config)

	def testReadConfig(self):
		config = self.createConfig('a=b')
		self.assertEquals({'a':'b'}, config)

	def testReadLongConfig(self):
		config = self.createConfig("""a=b
# commentaar
 aaaaa  = 5 

1=5""")
		self.assertEquals(3, len(config))
		self.assertTrue('aaaaa' in config)
		
	def testVariables(self):
		config = self.createConfig("""arg1=value1
arg2 = value<%(arg1)s>2
arg.one = 1
arg.two = 2*%(arg.one)s
""")
		self.assertEquals(4, len(config))
		self.assertEquals('value1', config['arg1'])
		self.assertEquals('value<value1>2', config['arg2'])
		self.assertEquals('2*1', config['arg.two'])
		

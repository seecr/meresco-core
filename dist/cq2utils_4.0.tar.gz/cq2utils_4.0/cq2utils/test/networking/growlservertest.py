# -*- encoding: utf-8 -*-
## begin license ##
#
#    "CQ2 Utils" (cq2utils) is a package with a wide range of valuable tools.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of "CQ2 Utils".
#
#    "CQ2 Utils" is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    "CQ2 Utils" is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with "CQ2 Utils"; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##

import unittest
from cStringIO import StringIO
from cq2utils.networking.growlserver import GrowlServer
from cq2utils.streams.readwritestream import ReadWriteStream
from cq2utils.basetestcase import BaseTestCase

document = """<document id="1">
...some content...
</document>"""

documents = """<?xml version="1.0"?>
<documents>
%s
</documents>"""

results_xml = """<?xml version="1.0"?><results>%s</results>"""

class GrowlServerTest(BaseTestCase):
	
	def setUp(self):
		self._processedDocuments = []
	
	def testCallProcess(self):
		streamIn = StringIO(documents % document)
		streamOut = StringIO()
		server = GrowlServer(ReadWriteStream(streamIn, streamOut))
		server._processDocument = self._processDocumentShunt
		server.process()
		
		self.assertEquals(1, len(self._processedDocuments))
		self.assertEqualsWS('<?xml version="1.0"?><results><result id="1"><status>OK</status><message></message></result></results>', streamOut.getvalue())

	def testWriteError(self):
		streamIn = StringIO(documents % document)
		streamOut = StringIO()
		server = GrowlServer(ReadWriteStream(streamIn, streamOut))
		server._processDocument = self._processDocumentShuntWithError
		server.process()
		result = streamOut.getvalue()
		self.assertTrue('<result id="1"><status>ERROR</status><message>Test Error Message</message></result>' in result)
		
	def _processDocumentShunt(self, aDocument):
		self._processedDocuments.append(aDocument)

	def _processDocumentShuntWithError(self, aDocument):
		raise Exception('Test Error Message')

if __name__ == '__main__':
    unittest.main()

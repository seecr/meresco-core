## begin license ##
#
#    "CQ2 Utils" (cq2utils) is a package with a wide range of valuable tools.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of "CQ2 Utils".
#
#    "CQ2 Utils" is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    "CQ2 Utils" is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with "CQ2 Utils"; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##

from unittest import TestCase
from uniquenumbergenerator import UniqueNumberGenerator, CHUNKSIZE
import tempfile
import os
from threading import Thread
from time import sleep

class UniqueNumberGeneratorTest(TestCase):
	
	def testBasicBehavior(self):
		self.assertEquals(0, self.generator.next())
		self.assertEquals(1, self.generator.next())
		self.assertEquals(2, self.generator.next())
		
	def testPersistency(self):
		for i in range(123):
			generatorsLastNumber = self.generator.next()
		otherGenerator = UniqueNumberGenerator(self.generator.filename)
		result = otherGenerator.next()
		self.assertTrue(result > generatorsLastNumber, "%i <= %i" % (result, generatorsLastNumber))
	
	def testReadsChunks(self):
		writeCalls = []
		def read():
			self.fail("Should not reach here")
		def write(nr):
			writeCalls.append(nr)
		self.generator._read = read
		self.generator._write = write
		for i in range(CHUNKSIZE):
			nr = self.generator.next()
			self.assertEquals(i, nr)
		self.assertEquals(CHUNKSIZE - 1, nr)
		self.assertEquals([CHUNKSIZE], writeCalls)
		self.assertEquals(CHUNKSIZE, self.generator.next())
		self.assertEquals([CHUNKSIZE, 2 * CHUNKSIZE], writeCalls)
		
	def testIsBlocking(self):
		results = [0,0]
		def collect1():
			results[0] = self.generator.next()
				
		def collect2():
			results[1] = self.generator.next()
				
		thread1 = Thread(None, collect1)
		thread2 = Thread(None, collect2)
		thread1.start(), thread2.start()
		thread1.join(), thread2.join()
		self.assertNotEquals(results[0], results[1])
		
	def testFileIsNeverEmpty(self):
		"""Ik heb geen idee hoe je dit moet testen. Het gaat om de atomaire move van de file."""
		pass
	
	def setUp(self):
		self.filename = tempfile.mktemp()
		self.generator = UniqueNumberGenerator(self.filename)
		
	def tearDown(self):
		if os.path.exists(self.filename):
			os.unlink(self.filename)	

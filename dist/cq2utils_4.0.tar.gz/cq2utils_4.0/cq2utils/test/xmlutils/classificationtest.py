## begin license ##
#
#    "CQ2 Utils" (cq2utils) is a package with a wide range of valuable tools.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of "CQ2 Utils".
#
#    "CQ2 Utils" is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    "CQ2 Utils" is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with "CQ2 Utils"; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##
import unittest
from cq2utils import binderytools
from cq2utils.wrappers import wrapp
import classification

LOM = "<lom>%s</lom>"

CLASSIFICATION = """<classification>
	<purpose>
		<source>
			<string	language="x-none">TPv1.0.2_anders</string>
		</source>
		<value>
			<string language="nl">%s</string>
		</value>
	</purpose>
	%s
</classification>"""

TAXONPATH = """<taxonPath>%s</taxonPath>"""

TAXON = """<taxon>
	<id>%s</id>
	<entry>
	<string language="nl">%s</string>
	<string language="en">%s</string>
	</entry>
</taxon>"""

class ClassificationTest(unittest.TestCase):
	def node(self, xmlString):
		return binderytools.bind_string(xmlString).classification
	
	def nodes(self, xmlString):
		return binderytools.bind_string(xmlString).lom.classification
	
	def testClassificationSinglePathSingleTAXON(self):
		node = self.node(CLASSIFICATION % ("discipline", TAXONPATH % TAXON % ("382", "Bouw", "Construction") ))
		classificationResult = classification.fromNode(node)
		self.assertEquals("discipline:/Bouw", classificationResult.flattenEntry())
		self.assertEquals("discipline:/382", classificationResult.flattenId())
	
	def testClassificationSinglePathSingleTAXONOtherLanguage(self):
		node = self.node(CLASSIFICATION % ("discipline", TAXONPATH % TAXON % ("382", "Bouw", "Construction") ))
		classificationResult = classification.fromNode(node, 'en')
		self.assertEquals("discipline:/Construction", classificationResult.flattenEntry())
		self.assertEquals("discipline:/382", classificationResult.flattenId())
		
	def testClassificationSinglePathMultipleTAXONs(self):
		TAXON382 = TAXON % ("382", "Bouw", "Construction")
		TAXON383 = TAXON % ("383", "Dakbedekking", "Roof")
		singlePathMultipleTAXONs = CLASSIFICATION % ("discipline", TAXONPATH % (TAXON382 + TAXON383))

		node = self.node(singlePathMultipleTAXONs)
		classificationResult = classification.fromNode(node)
		
		self.assertEquals("discipline:/Bouw/Dakbedekking; discipline:/Bouw", classificationResult.flattenEntry())
		self.assertEquals(["/Bouw/Dakbedekking"], classificationResult.getEntries())
		
		self.assertEquals("discipline:/382/383; discipline:/382", classificationResult.flattenId())
	
	def testClassificationMultiplePaths(self):
		path1 = TAXONPATH % TAXON % ("704", "Installatietechniek", "Installation")
		path2 = TAXONPATH % TAXON % ("3172", "Tabs en spaties    	", "Tabs and spaces	 	")
		path3 = TAXONPATH % TAXON % ("2479", "Branche", "Department")
		multiplePaths = CLASSIFICATION % ("discipline", path1 + path2 + path3)
		
		node = self.node(multiplePaths)
		classificationResult = classification.fromNode(node)
		
		self.assertEquals("discipline:/Installatietechniek; discipline:/Tabs en spaties; discipline:/Branche", classificationResult.flattenEntry())
		self.assertEquals('discipline', classificationResult.getPurpose())
		self.assertEquals(['/Installatietechniek', '/Tabs en spaties', '/Branche'], classificationResult.getEntries())
		
	def testClassificationMultipleClassifications(self):
		classification1 = CLASSIFICATION % ("education level", TAXONPATH % TAXON % ("xxx", "xxxxxx", "yyyyy"))
		classification2 = CLASSIFICATION % ("discipline", TAXONPATH % TAXON % ("704", "Installatietechniek", "Installation"))
		classification3 = CLASSIFICATION % ("discipline", TAXONPATH % TAXON % ("3172", "Tabs en spaties    	", "Tabs and spaces 	 "))
		
		classifications = self.nodes(LOM % (classification1 + classification2 + classification3))
		classificationResult = classification.aggregate(classifications)
		
		self.assertEquals("discipline:/Installatietechniek; discipline:/Tabs en spaties", classificationResult.flattenEntry("discipline"))
		self.assertEquals(["discipline", "education level"], classificationResult.getPurposes())
		self.assertEquals("", classificationResult.flattenEntry("not existing"))
	

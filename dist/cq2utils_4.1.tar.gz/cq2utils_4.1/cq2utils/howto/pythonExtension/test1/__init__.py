## begin license ##
#
#    "CQ2 Utils" (cq2utils) is a package with a wide range of valuable tools.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of "CQ2 Utils".
#
#    "CQ2 Utils" is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    "CQ2 Utils" is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with "CQ2 Utils"; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##


def _init():
	"""Initialize this python module by compiling things.
	Hides the imported modules for users."""
	from os import system, stat
	from stat import ST_MTIME
	from os.path import abspath, join, isfile

	# __path__ can contain multiple paths, this is not supported yet
	assert(len(__path__) == 1)
	mypath =  abspath(__path__[0])
	modulename = 'test1'
	libdir = 'lib'

	statWithExists = lambda filename: isfile(filename) and stat(filename)[ST_MTIME] or -1
	
	# Only run SWIG when the header file (.h) or input file (.i) is newer
	modtimeHeader = stat(join(mypath, modulename +'.i'))[ST_MTIME]
	modtimeInput = stat(join(mypath, modulename + '.h'))[ST_MTIME]
	modtimeOutput = statWithExists(join(mypath, modulename + '.py'))
	if modtimeInput > modtimeOutput or modtimeHeader > modtimeOutput:
		print 'running SWIG...'
		system('cd %s; swig -python -c++ %s.i' % (mypath, modulename))
		#Check if swig has created new file
		modtimeNewOutput = stat(join(mypath, modulename + '.py'))[ST_MTIME] 
		if modtimeNewOutput == modtimeOutput: 
			print 'SWIG Failed!'
		else: print 'SWIG Succeeded!'

	# Compile and install the wrapper into ./lib when needed
	system('cd %s; python setup.py install --install-lib=./%s' % (mypath,libdir))
	
	# Add the path for the new wrapper to the global path
	import sys
	sys.path.append(join(mypath,libdir))
	
_init()

# Export the 'public' stuff
from test1 import TestClass1

## begin license ##
#
#    "CQ2 Utils" (cq2utils) is a package with a wide range of valuable tools.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of "CQ2 Utils".
#
#    "CQ2 Utils" is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    "CQ2 Utils" is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with "CQ2 Utils"; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##
import unittest, os
from cq2utils.networking.sshclient import SSHClient, openClient
from time import sleep

largeNumber = 65000

class SSHClientTest(unittest.TestCase):
	"""This test requires you to be able to login using ssh on your own machine, without further intervention from the user
	$ ssh-keygen -t rsa  [either no passphrase, or add the passphrase using ssh-add]
	$ echo ~/.ssh/id_rsa.pub >> ~/.ssh/authorized_keys
	$ ssh [yourhostname]   [validate all questions]
	"""
	
	def setUp(self):
		self.hostname = 'localhost'
		self.username = os.environ['USER']
		self.path = os.path.realpath('') #werkt niet bij aanroepen vanuit andere plaatsen
	
	def testConnect(self):
		client = self._client('ls')
		try:
			self.assertTrue(client)
		finally:
			client.close()
			
	def testWrite(self):
		if os.path.isfile('x.tmp'):
			os.unlink('x.tmp')
		client = self._client('cat >  %s/x.tmp' % self.path)
		try:
			client.write('something\n')
			sleep(3) # on really slow machines this is really needed, don't lower this value (KVS)
			self.assertEquals('something\n', self._read('x.tmp')) 
		finally:
			client.close()
			os.unlink('x.tmp')
 
	def testRead(self):
		client = self._client('echo something')
		try:
			self.assertEquals('something\n', client.read(largeNumber)) 
		finally:
			client.close()
	
	def testEcho(self):
		client = self._client('python %s/echo_once.py' % self.path)
		try:
			client.write('something\n')
			self.assertEquals('RESPONSE: something\n', client.read(largeNumber))
		finally:
			client.close()
			
	def testCreateCallString(self):
		expected = ['/usr/bin/ssh', '-p', 'aPort', '-i', 'aFilename', '-l', 'aUsername', 'aHostname', 'aCommand']
		client = SSHClient('aHostname', 'aPort', 'aUsername', 'aKey', 'aCommand')
		client._writeKeyToFile = lambda: 'aFilename'
		client.openConnection()
		
		callString = client._createCallString()
		self.assertEquals('/usr/bin/ssh -o BatchMode=yes -p aPort -i aFilename -l aUsername aHostname "aCommand"', callString)


	def testExceptionsAreNicelyformatted(self):
		print "\nBookmark: (sshclient) next step: testExceptionsAreNicelyformatted - i.e. not 'broken pipe' but something indicating ssh failed"
		"bookmark 2: kill ssh clients"
		"bookmark 3: test waitForServerClose"
	
	def _client(self, remoteCommand):
		return openClient(
			hostname = self.hostname,
			port = 22,
			username = self.username,
			privatekey = open(os.environ['HOME'] + '/.ssh/id_rsa').read(),
			remoteCommand = remoteCommand)
	
	def _read(self, filename):
		f = open(filename)
		try:
			result = f.read()
		finally:
			f.close()
		return result
 
if __name__ == '__main__':
	unittest.main()

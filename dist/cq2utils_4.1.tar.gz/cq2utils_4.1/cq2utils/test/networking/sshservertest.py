## begin license ##
#
#    "CQ2 Utils" (cq2utils) is a package with a wide range of valuable tools.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of "CQ2 Utils".
#
#    "CQ2 Utils" is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    "CQ2 Utils" is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with "CQ2 Utils"; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##
from cq2utils.networking.sshserver import TMPDIR, SSHServer, SSHServerException
import unittest
import os

class ThisClassHasNoConstructorMethod:
	pass

class ThisClassHasNoProcessMethod:
	def __init__(self, stream, args):
		self.stream = stream
		self.args = args
		
class ThisClassProcesses(ThisClassHasNoProcessMethod):
	def process(self):
		self.stream.write('processed')

class SSHServerTest(unittest.TestCase):
	def assertNoTMPDIR(self):
		os.path.isdir(TMPDIR) and	os.system('rm -rf ' + TMPDIR)
		
	def setUp(self):
		self.assertNoTMPDIR()
		
	def tearDown(self):
		self.assertNoTMPDIR()
		
	def testSplitModuleAndClassname(self):
		server = SSHServer("some.cats.PersianCat")
		self.assertEquals('some.cats', server._moduleName)
		self.assertEquals('PersianCat', server._className)
		
	def testImportGarbage(self):
		try:
			server = SSHServer("notice the lack of a dot and the spaces")
			self.fail()
		except SSHServerException, e:
			self.assertEquals("Invalid qualified classname", str(e))
			self.assertTrue(os.path.isdir('/tmp/sshserver'))
			self.assertEquals('Invalid qualified classname', open('/tmp/sshserver/' + os.listdir('/tmp/sshserver')[0]).read())
		
	def testImportNonExistingClass(self):
		try:
			server = SSHServer("non.existing.module.NonExistingClass")
			server.main()
			self.fail()
		except SSHServerException, e:
			self.assertEquals("No module named non.existing.module", str(e))
		
	def testImportClassWithoutConstructor(self):
		try:
			server = SSHServer("sshservertest.ThisClassHasNoConstructorMethod")
			server.main()
			self.fail()
		except SSHServerException, e:
			self.assertEquals("this constructor takes no arguments", str(e))
		
	def testImportClassWithoutProcessMethod(self):
		try:
			server = SSHServer("sshservertest.ThisClassHasNoProcessMethod")
			server.main()
			self.fail()
		except SSHServerException, e:
			self.assertEquals("ThisClassHasNoProcessMethod instance has no attribute 'process'", str(e))
			
	def testDo(self):
		server = SSHServer("sshservertest.ThisClassProcesses")
		server.main()

#include "test1.h"

TestClass1::TestClass1(void) {
  _aString = "string0";
};

std::string TestClass1::helloWorld(void) {
  return "Hello!";
};

std::string TestClass1::getString(void) {
 return _aString;
};

std::string TestClass1::passString(std::string aString) {
  std::string retval = _aString;
  _aString = aString;
  return retval;
};
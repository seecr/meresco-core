## begin license ##
#
#    "CQ2 Utils" (cq2utils) is a package with a wide range of valuable tools.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of "CQ2 Utils".
#
#    "CQ2 Utils" is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    "CQ2 Utils" is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with "CQ2 Utils"; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##
import re
import urllib2
import time, sys

r = re.compile('href="(/[^"]*)"')
site = 'http://testdare2.cq2.org'
max_next_pages = 30

class ToDo:
	def __init__(self):
		self.d = {}
		
	def addElem(self, path, depth):
		if not self.d.has_key(path) or self.d[path] > depth:
			self.d[path] = depth
		
	def pop(self):
		result = sorted(map(lambda (x, y): (y, x), self.d.items()))[0]
		del(self.d[result[1]])
		return result
		
	def hasnext(self):
		return self.d
	
class Crawler:
	def __init__(self, maxdepth):
		self.result = set()
		self.todo = ToDo()
		self.maxdepth = maxdepth
	
	def crawlPage(self, url):
		before = time.time()
		page = urllib2.urlopen(url).read()
		duration = str(time.time() - before)
		resultset = set(r.findall(page)[:max_next_pages]) - self.result
		return resultset, duration
	
	def crawl(self, path):
		self.todo.addElem(path, 0)
		while self.todo.hasnext():
			depth, path = self.todo.pop()
			sys.stdout.write(path)
			sys.stdout.flush()
			if depth > self.maxdepth:
				return
			try:
				newpaths, duration_or_error = self.crawlPage(site + path)
			except urllib2.HTTPError, e:
				newpaths = set()
				duration_or_error = "ERROR " + str(e)
			print >> sys.stdout, "\t" + duration_or_error + "\t" + str(depth)
			sys.stdout.flush()
			
			for newpath in newpaths:
				self.todo.addElem(newpath, depth + 1)
			self.result = self.result.union(newpaths)

x = Crawler(10)
x.crawl('/')
for link in x.result:
	print link

## begin license ##
#
#    "CQ2 Utils" (cq2utils) is a package with a wide range of valuable tools.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of "CQ2 Utils".
#
#    "CQ2 Utils" is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    "CQ2 Utils" is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with "CQ2 Utils"; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##
import unittest, os
from popen2 import Popen3 as popen
import tempfile
from cq2utils.streams.osreadstream import OSReadStream
import signal

class OSReadStreamTest(unittest.TestCase):
	"""Note that some crucial behavior is not tested (yet?) - especially concerning blocking"""

	def setUp(self):
		self.tmp = tempfile.NamedTemporaryFile()
		self.pipe = popen('tail -f ' + self.tmp.name, True)
		self.originalReadStream = self.pipe.fromchild
		self.wrappedReadStream = OSReadStream(self.originalReadStream.fileno())
		
		notbuffered = 0
		self.writeStream = open(self.tmp.name, 'w', notbuffered)
		
	def tearDown(self):
		os.kill(self.pipe.pid, signal.SIGTERM)

	def testReadZero(self):
		pass
		# Not tested, since it is blocking

	def testReadOneByte(self):
		self.writeStream.write('content')
		
		### The following commented line blocks - which is the purpose of the OSReadStream, instead we use the line just after that
		# result = self.originalReadStream.read(10)
		result = self.wrappedReadStream.read(1)
		self.assertEquals('c', result)
	
	def testRead(self):
		self.writeStream.write('content')
		
		### The following commented line blocks - which is the purpose of the OSReadStream, instead we use the line just after that
		# result = self.originalReadStream.read(1024)
		result = self.wrappedReadStream.read(1024)
		self.assertEquals('content', result)
	
	
	def testReadTwice(self):
		self.writeStream.write('abc')
		
		result1 = self.wrappedReadStream.read(1)
		result2 = self.wrappedReadStream.read(2)
		
		self.assertEquals('a', result1)
		self.assertEquals('bc', result2)
	
	def testReadAll(self):
		self.writeStream.write('content bla')
		
		try:
			self.wrappedReadStream.read(-1)
			self.fail()
		except Exception, e:
			self.assertEquals('OSReadStream has no support for -1 bytes', str(e))
			
	def testEOF(self):
		EOF = '\4'
		self.writeStream.write('contents%smore contents' % EOF)
		self.assertEquals('contents', self.wrappedReadStream.read(1024))
		self.assertEquals('', self.wrappedReadStream.read(1024))
		
		

if __name__ == '__main__':
	unittest.main()

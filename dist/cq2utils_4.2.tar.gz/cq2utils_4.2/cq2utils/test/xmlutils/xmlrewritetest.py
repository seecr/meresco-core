## begin license ##
#
#    "CQ2 Utils" (cq2utils) is a package with a wide range of valuable tools.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of "CQ2 Utils".
#
#    "CQ2 Utils" is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    "CQ2 Utils" is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with "CQ2 Utils"; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##
from unittest import TestCase
from lxml.etree import parse, tostring, XMLParser
from xmlrewrite import XMLRewrite
from StringIO import StringIO
from difflib import unified_diff

class XMLRewriteTest(TestCase):

	def assertRewrite(self, rules, newRootTagName, soll, src, namespace=None):
		rewrite = XMLRewrite(parse(StringIO(src)), newRootTagName, namespace, rules, {})
		rewrite.applyRules()
		istText = rewrite.toString()
		s = parse(StringIO(soll), XMLParser(remove_blank_text=True))
		sollText = tostring(s, pretty_print=True)
		diffs = list(unified_diff(sollText.split('\n'), istText.split('\n'), fromfile='ist', tofile='soll', lineterm=''))
		self.assertFalse(diffs, '\n' + '\n'.join(diffs))

	def testOneValue(self):
		# newTag, oldTag, valuesWithInOldTag, template
		rules = [('.', 'b', ('.',), '<y>%s</y>')]
		src = '<a><b>aap</b></a>'
		dst = '<z><y>aap</y></z>'
		self.assertRewrite(rules, 'z', dst, src)
	
	def testEscaping(self):
		# newTag, oldTag, valuesWithInOldTag, template
		rules = [('y', 'b', ('c',), '<x>%s</x>')]
		src = '<a><b><c>a&amp;b</c></b></a>'
		dst = '<z><y><x>a&amp;b</x></y></z>'
		self.assertRewrite(rules, 'z', dst, src)


	def testWithTwoValues(self):
		rules = [('.', '.', ('b', 'c'), '<ownTag attr="%s">%s</ownTag>')]
		src = '<a><b>aap</b><c>noot</c></a>'
		dst = '<z><ownTag attr="aap">noot</ownTag></z>'
		self.assertRewrite(rules, 'z', dst, src)

	def testSubPaths(self):
		rules = [('y', '.', ('b',), '<w>%s</w>')]
		src = '<a><b>aap</b></a>'
		dst = '<z><y><w>aap</w></y></z>'
		self.assertRewrite(rules, 'z', dst, src)

	def testSubPathsInSource(self):
		rules = [('y/x', 'b/c/d', ('e',), '<w>%s</w>')]
		src = '<a><b><c><d><e>aap</e></d></c></b></a>'
		dst = '<z><y><x><w>aap</w></x></y></z>'
		self.assertRewrite(rules, 'z', dst, src)

	def testTwoRules(self):
		rules = [	('y', 'b', ('.',), '<w>%s</w>'),
						('x', 'c', ('.',), '<v>%s</v>')]
		src = '<a><b>aap</b><c>noot</c></a>'
		dst = '<z><y><w>aap</w></y><x><v>noot</v></x></z>'
		self.assertRewrite(rules, 'z', dst, src)

	def testMultipleSourceTagsEndUpInSameAmountOfDstTags(self):
		# for each tag 'b' an tag /z/y is generated
		rules = [	('y', 'b', ('.',), '<w>%s</w>'),
						('x', 'c', ('.',), '<v>%s</v>')]
		src = '<a><b>aap</b><b>mies</b><c>noot</c></a>'
		dst = '<z><y><w>aap</w></y><y><w>mies</w></y><x><v>noot</v></x></z>'
		self.assertRewrite(rules, 'z', dst, src)

	def testPandQareInSameContext(self):
		rules = [	('y/p', 'b', ('.',), '%s'),
						('y/q', 'c', ('.',), '%s')]
		src = '<a><b>aap</b><b>mies</b><c>noot</c></a>'
		dst = '<z><y><p>aap</p><p>mies</p><q>noot</q></y></z>'
		self.assertRewrite(rules, 'z', dst, src)

	def testNotAllElementsAreEqual(self):
		rules = [	('y/p', 'b/c', ('.',), '%s'),
						('y/q', 'b/d', ('.',), '%s')]
		src = '<a><b><c>aap</c></b><b><c>mies</c><d>noot</d></b></a>'
		dst = '<z><y><p>aap</p></y><y><p>mies</p><q>noot</q></y></z>'
		self.assertRewrite(rules, 'z', dst, src)

	def testNestedAndRepeatedElementsForPathDir(self):
		rules = [	('path', 'path', ('source',), '<src>%s</src>'),
						('path', 'path', ('dir',), '<directory>%s</directory>')]
		src = '<a><path><source>A</source><dir>B</dir><dir>C</dir></path>'  \
						'<path><source>D</source><dir>E</dir><dir>F</dir></path></a>'
		soll = '<x><path><src>A</src><directory>B</directory><directory>C</directory></path>' \
						'<path><src>D</src><directory>E</directory><directory>F</directory></path></x>'
		self.assertRewrite(rules, 'x', soll, src)

	def testXPathNameSpaces(self):
		src = '<x:a xmlns:x="http://x"><x:b>aap</x:b></x:a>'
		rules = [('p', 'Q:b', ('.',), '%s')]
		rewrite = XMLRewrite(parse(StringIO(src)), 'A', 'http://y', rules, vocabDict={}, xPathNs={'Q': 'http://x'})
		rewrite.applyRules()
		self.assertEquals('<A xmlns="http://y">\n  <p>aap</p>\n</A>', rewrite.toString())

	def testXPathWithSlashes(self):
		src = '<a><b>B1<c><d>aap</d></c></b><b>B2<c><d>noot</d></c></b></a>'
		rules = [('p', 'b[c/d="aap"]', ('.',), '%s')]
		rewrite = XMLRewrite(parse(StringIO(src)), 'A', None, rules, vocabDict={})
		rewrite.applyRules()
		self.assertEquals('<A>\n  <p>B1</p>\n</A>', rewrite.toString())

	def testCompleteRecord(self):
		data = open('data/triple-lrecord.xml')
		rules = [
#contextPath, oldElementPath, valuePaths, template
('general/title', 'general/title/langstring', ('language', 'value'), '<string language="%s">%s</string>'),
('general', 'general/catalogentry', ('catalog', 'entry/langstring/value'), '<identifier><catalog>%s</catalog><entry>%s</entry></identifier>'),
('general', 'general/grouplanguage', ('.',), '<language>%s</language>'),
('general/description', 'general/description/langstring', ('language', 'value'), '<string language="%s">%s</string>\n'),
('lifeCycle/contribute', 'lifecycle/contribute/role', ('source/langstring/value', 'value/langstring/value'), '<role><source>%s</source><value>%s</value></role>'),
('lifeCycle/contribute', 'lifecycle/contribute/centity', ('vcard',), '<entity>%s</entity>'),
('lifeCycle/contribute/date', 'lifecycle/contribute/date', ('datetime',), '<dateTime>%s</dateTime>',
	 (('(\d{2,4}-\d{2}-\d{2}) (\d{2}:\d{2})', '%sT%s',),)),
('metaMetadata', 'metametadata/metadatascheme', ('.',), '<metadataSchema>%s</metadataSchema>'),
('technical/format', 'technical/format', ('.',), '%s'),
('technical/location', 'technical/location', ('value',), '%s'),
('educational', 'educational/learningresourcetype', ('source/langstring/value', 'value/langstring/value'), '<learningResourceType><source>%s</source><value>%s</value></learningResourceType>'),
('educational', 'educational/context', ('source/langstring/value', 'value/langstring/value'), '<context><source>%s</source><value>%s</value></context>'),
('rights', 'rights/cost', ('source/langstring/value', 'value/langstring/value'), '<cost><source>%s</source><value>%s</value></cost>'),
('rights', 'rights/copyrightandotherrestrictions', ('source/langstring/value', 'value/langstring/value'), '<copyrightAndOtherRestrictions><source>%s</source><value>%s</value></copyrightAndOtherRestrictions>'),
('classification', 'classification/purpose', ('source/langstring/value', 'value/langstring/value'), '<purpose><source>%s</source><value>%s</value></purpose>'),
('classification/taxonPath/source', 'classification/taxonpath/source/langstring', ('language', 'value'), '<string language="%s">%s</string>'),
('classification/taxonPath', 'classification/taxonpath', ('taxon/id',), '<taxon><id>%s</id></taxon>'),
('classification/taxonPath/taxon/entry', 'classification/taxonpath/taxon/entry', ('langstring/language', 'langstring/value'), '<string language="%s">%s</string>\n'),

]
		"""
"""

		should = """<lom>
<general>
<title>
<string language="nl">Religie Nu (12) Kan theater zonder religie?</string>
</title>
<identifier>
<catalog>nl.uva.uba.triple-l</catalog>
<entry>217134</entry>
</identifier>
<language>nl</language>
<description>
<string language="nl">Kunst zonder God is een verarming.

Religie - een wijder begrip schenkt kleur en diepgang aan het leven in de kunst. In dramatisch opzicht geven goden de mogelijkheid aan de toneelschrijver de geest van de mens te projecteren. Grote schrijvers hebben ver voor het Christendom zijn intrede deed de mens in de kosmos geplaatst, van waaruit allerlei krachten hem bedreigen of te hulp schieten of hem uitdagen. Van Aischylos tot Sartre, van Shakespeare tot Beckett hebben goden het leven van dramatische figuren benvloed. En zo zal het blijven. Het wachten is op Godot.</string>
</description>
</general>
<lifeCycle>
<contribute>
<role>
<source>LOMv1.0</source>
<value>Speaker</value></role>
<entity>
BEGIN:VCARD
VERSION:2.1
N:Vos;E.
FN:E. Vos
END:VCARD
				</entity>
<date>
<dateTime>2006-11-28T19:00</dateTime></date>
</contribute>
</lifeCycle>
<metaMetadata>
<metadataSchema>LORENET</metadataSchema>
</metaMetadata>
<technical>
<format>text/html</format>
<location>http://www.iis-communities.nl/access/content/group/Religie/MAP%201/College%2012%20-%20Erik%20Vos%20-%2028-11-06</location></technical>
<educational>
<learningResourceType>
<source>TPPOVOv1.0</source>
<value>informatiebron</value>
</learningResourceType>
<context>
<source>TPPOVOv1.0</source>
<value>WO</value>
</context>
</educational>
<rights>
<cost>
<source>LOMv1.0</source>
<value>nee</value>
</cost>
<copyrightAndOtherRestrictions>
<source>CCv2.5</source>
<value>http://creativecommons.org/licenses/by-nc-sa/2.5/nl/</value>
</copyrightAndOtherRestrictions>
</rights>
<classification>
<purpose>
<source></source>
<value></value>
</purpose>
<taxonPath>
<source>
<string language="x-none">NBC</string></source>
<taxon>
<id>24</id>
<entry>
<string language="nl">Theaterwetenschap, muziekwetenschap</string>
<string language="en">Dramaturgy, musicology</string>
</entry>
</taxon>
</taxonPath>
</classification>
</lom>
"""
		self.assertRewrite(rules, 'lom', should, data.read())

	def testTaxonPath(self):
		src ="""<root>
			<classification>
				<taxonpath>
					<taxon>
						<id>2</id>
						<entry>
							<langstring><value>aap</value></langstring>
							<langstring><value>noot</value></langstring>
						</entry>
					</taxon>
				</taxonpath>
				<taxonpath>
					<taxon>
						<id>1</id>
						<entry>
							<langstring><value>boom</value></langstring>
							<langstring><value>vuur</value></langstring>
						</entry>
					</taxon>
				</taxonpath>
			</classification>
			</root>"""
		dst = """<lom>
  <classification>
    <taxonPath>
      <taxon>
        <entry>
          <ja>aap</ja>
          <ja>noot</ja>
        </entry>
      </taxon>
    </taxonPath>
    <taxonPath>
      <taxon>
        <entry>
          <ja>boom</ja>
          <ja>vuur</ja>
        </entry>
      </taxon>
    </taxonPath>
  </classification>
</lom>"""
		rules = [
					#('classification', 'classification', ('taxonPath/taxon/id',), '<taxonPath><taxon><id>%s</id></taxon></taxonPath>'),
					('classification/taxonPath/taxon/entry', 'classification/taxonpath/taxon/entry', ('langstring/value',), '<ja>%s</ja>') ]
		self.assertRewrite(rules, 'lom', dst, src)

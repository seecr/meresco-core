#!/bin/bash
cd $(dirname $0)/cq2utils/install
./install.sh $*

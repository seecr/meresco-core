from distutils.core import setup

setup(
    name='cqlparser',
    packages=['cqlparser'],
)

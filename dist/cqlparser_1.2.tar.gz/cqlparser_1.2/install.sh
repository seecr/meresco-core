#!/bin/bash
cd $(dirname $0)/cqlparser/install
./install.sh $*
